# React + Vite

To Run THe app First create a recat+vite app
by using npm create vite@latest

also install 
npm install react-router-dom json-server
npm install Bootstrap
npm run dev

in a new terminal run the command
npx json-server --watch db.json --port 5000

